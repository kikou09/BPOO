public abstract class Capacite implements ICapacite {
	private String nom;
	private String description;
	int utilise ;
	int degats ;
	
	public Capacite(String n, String d){
		if(n==null)
			throw new ExceptionHearthsone("Le nom de la capacité ne doit pas être null ");
		if(d==null)
			throw new ExceptionHearthsone("Il faut une description ");
		this.nom=n;
		this.description=d;
		this.degats=0;
	}
	
	public Capacite(String n, String d, int deg ){
		if(n==null)
			throw new ExceptionHearthsone("Le nom de la capacité ne doit pas être null ");
		if(d==null)
			throw new ExceptionHearthsone("Il faut une description ");
		this.nom=n;
		this.description=d;
		this.degats=deg;
	}
	
	public String getNom() {
		return this.nom;
	}
	
	public String getDescrpition() {
		return this.description;
	}
	
	public String toString()
	{
		return "Capacite [nom=" + this.nom + ", description=" + this.description + "]";
	}
	
}