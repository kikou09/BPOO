public abstract class Interface {
	
	private Interface suivant=null;
	
	public Interface (Interface suivant){
		this.suivant=suivant;
	}
	public abstract boolean saitInteragir(String choix);
	public abstract void executerInteraction(Dessin d);
	public abstract String getDescription();
	public void interagir(String choix , Dessin d) {
		if (saitInteragir(choix))
			executerInteraction(d);
		else if(suivant !=null)
			suivant.interagir(choix, d);
		else
			throw new Exception ("Pas d'interaction pour " + choix + "\n");
	}
}

public class InterfaceQuitter extends Interface {
	public InterfaceQuitter(Interface suivant){
		super(suivant);
	}
	
	public String getDescription() {
		return "Quitter";
	}
	
	public bool saitInteragir(String nom){
		return getDescription().equals(nom);
	}
	
	public void executerInteraction(Dessin d){
		es.println("Au revoir");
		system.exit(0);
	}
}

public class Application {
	private static Interface ihm=null;
	private static Dessin dessin= new Dessin();
	public static final Console es=new Console();
	public static void main (String[] args){
		
		ihm=initialiserInterface();
		if(ihm==null)
		{
			es.println("L'application ne fait rien ... \n");
			system.exit(0);
		}
		while(true){
			String choix=menu();
			try{
				ihm.interagir(choix , dessin);
			}
			catch(Exception e){
				es.printStackTrace();
			}
		}
	}
	
	public static String menu(){
		ArrayList<String> menu=new ArrayList<String>;
		Interface i=ihm;
		while(i!=null){
			menu.add(i.getDescription());
			i=i-getSuivant(i);
		}
		int n=0;
		for(String s : menu){
			es.println("" + n + " " + s);
			n++;
		}
		es.println("Votre choix : \n ");
		int c=es.readInt();
		return menu.get(c);
	}
	
	public static Interface initialiserInterface () {
		Interface monInterface=null;
		monInterface= new InterfaceQuitter(monInterface);
		monInterface=newInterfaceCercle(monInterface);
		.
		.
		.
	}
}