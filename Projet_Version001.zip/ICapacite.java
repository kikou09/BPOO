public abstract interface ICapacite{
	public abstract void executerAction(java.lang.Object cible)throws jeu.ExceptionHearthstone;
	public abstract void executerEffetDebutTour()throws jeu.ExceptionHearthstone;
	public abstract void executerEffetDisparition(java.lang.Object cible)throws jeu.ExceptionHearthstone;
	public abstract void executerEffetFinTour()throws jeu.ExceptionHearthstone;
	public abstract void executerEffetMiseEnJeu(java.lang.Object cible)throws jeu.ExceptionHearthstone;
	public abstract String getDescription();
	public abstract String getNom();

}
