public final class Deck extends Carte {
	
	private ArrayList<ICarte> cartes_deck ;
	
}