public final class Plateau implements IPlateau {

	private static ????
	private IJoueur joueurCourant;
	private boolean demarree;
	private ArrayList joueurPresents;  //JoueursPresents dans le jeu 
	
	private Plateau()   //Constructeur
	{
		this.adversaire=null;
		this.joueurCourant=null;
		this.demarrer=false;
		this.joueurPresentes=newArrayList();
	}
	
	public final IJoueur getJoueurCourant(){
		if(!demarree)
			return null;

		return this.joueurCourant;
	}
	
	public final void setJoueurCourant(IJoueur joueur) throws jeu.ExceptionHearthstone
	{
		if (joueur == null)
			throw new ExceptionHearthsone("Le joueur ne doit pas être null");
		if(joueurCourant!=joueur)
			this.joueurCourant=joueur
	
	public final IJoueur getAdversaire(IJoueur joueur) throws jeu.ExceptionHearthstone
	{
		if(!= demarree)
			throw new ExceptionHearthsone("La partie n'a pas encore commencé");
		if(joueur==null)
			throw new ExceptionHearthsone("On ne peut pas recuperer l'adversaire d'un joueur null ");
		if(!JoueurPresents.contains(joueur)==null)
			throw new ExceptionHearthsone("Ce joueur n'est même pas dans la partie");
		if(this.joueurPresents.get(0) != joueur)
			return this.joueurPresents.get(0);
		else	
			return this.joueurPresents.get(1);
	
	private String toString(){
	
	}
	
	public final void ajouterJoueur(IJoueur joueur) throws jeu.ExceptionHearthstone{
		if (this.demarrerPartie)
			throw new ExceptionHearthsone("La partie a deja commencé");
		if(this.JoueurPresents.contains(joueur))
			throw new ExceptionHearthsone("Ce joueur est deja présent dans la partie");
		if(this.JoueurPresents.size()==2)
			throw new ExceptionHearthsone("Vous ne pouvez plus ajouter de joueur dans la partie");
		else
			this.JoueurPresents.add(Joueur);
	}
	
	public final void demarrerPartie() throws jeu.ExceptionHearthstone{
		if (this.demarrerPartie)
			throw new ExceptionHearthsone("La partie n'a pas encore commencé");
		if(this.JoueurPresents.size()!=2)
			throw new ExceptionHearthsone("Il faut 2 joueurs pour pouvoir jouer");
		
		this.Demarree=true;
		
	}
	
	public final void finTour(IJoueur Joueur) throws jeu.ExceptionHearthstone{
		if(!this.Demarree)
			throw new ExceptionHearthsone("La partie n'a pas encore commencé");
		else if (this.JoueurCourant!=Joueur)
			throw new ExceptionHearthsone("C'est n'est pas ton tour");
	
	}
	
	public final boolean estDemarree(){
	
		return this.Demarree;
	}
	
	public final void gagnePartie (IJoueur joueur) throws jeu.ExceptionHearthstone{
		this.demarree=false;
		msg="***"+this.JoueurCourant.getNom() + "a gagné !";
		
		System.out.println(msg);
	
	}
	
}