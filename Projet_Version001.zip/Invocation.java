public class Invocation extends Capacite {
	
	private Serviteur serviteur_invoque ;
	
	public Invocation ( String nom , String des , Serviteur s )
	{
		super(nom , des ) ;
		
		if(s==null)
		{
			throw new ExceptionHearthsone("Le serviteur ne doit pas être null");
		}
		this.serviteur_invoque=s;
	}
	
	public getServiteur_invoque(){
		return this.serviteur_invoque;
	}
}
