public final class Serviteur extends Carte {

	private int point_attaque;
	private int point_vie;
	private int attente;
	private int deja_attaque ???;
	private Capacite capacite;
	
	public Serviteur( String n , int cout , IJoueur j , int attaque , int vie, Capacite c)
	{
		super(n,c,j);
		if(vie==0)
			throw new ExceptionHearthsone("Les points de vies ne doivent pas être égales à 0");
		if(attaque==0)
			throw new ExceptionHearthsone("Les points d'attaque ne doivent pas être egales à 0");
		this.point_attaque=attaque;
		this.point_vie=vie;
		this.capacite=c;
	}
	
	public Serviteur ( Serviteur s)
	{
		super(s.nom , s.cout . s.proprietaire)
		this.point_attaque=s.point_attaque;
		this.point_vie=s.point_vie;
		this.capacite=s.capacite;
	}
	
	public int getAttaque(){
		return this.point_attaque;
	}
	
	public int getVie(){
		return this.point_vie;
	}
	
	public final void executerAction(Object o){
		if (this.attente !=0)
			throw new ExceptionHearthsone("Impossible de la jouer à ce tour ci");
	}
	
	public final boolean Disparait()
	{
		return this.point_vie <= 0;
	}
	
	public final String toString()
	{
		return " Serviteur [ " + super.toString() + " " attaque = " + this.point_attaque + " vie = " + this.point_vie + " ] " ; ??? 
	}
	
	public final void subitAttaque ( int degat )
	{
		this.point_vie = this.point_vie - degat ;
	}
	
	public final void gagneVie( int nb)
	{
		this.point_vie = this.point_vie + degat ;
	} 
	
	public final void setAttente(int tour)
	{
		this.attente=tour;
	}
	
	public final Object clone (){
		return new Serviteur(this);
	}

}