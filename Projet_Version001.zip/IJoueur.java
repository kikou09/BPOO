public abstract interface IJoueur{

	public static int MAX_MANA=1;
	public static int TAILLE_DECK=15;
	
	public abstract void finirTour()throws jeu.ExceptionHearthstone;
	public abstract ICarte getCarteEnJeu();
	public abstract ICarte getCarteEnMain();
	public abstract jeu.Heros getHeros();
	public abstract ArrayList<ICarte> getJeu();
	public abstract ArrayList<ICarte> getMain();
	public abstract int getMana();
	public abstract int getPseudo();
	public abstract int getStockMana();
	public abstract void jouerCarte(ICarte carte)throws jeu.ExceptionHearthstone;
	public abstract void jouerCarte(ICarte carte, java.lang.Object cible) throws jeu.ExceptionHearthstone;
	public abstract void perdreCarte(ICarte carte)throws jeu.ExceptionHearthstone ;
	public abstract void piocher()throws jeu.ExceptionHearthstone;
	public abstract void prendreTour()throws jeu.ExceptionHearthstone;
	public abstract void utiliserCarte(ICarte carte, java.lang.Object cible)throws jeu.ExceptionHearthstone;
	public abstract void utiliserPouvoir(java.lang.Object cible)throws jeu.ExceptionHearthstone;
}


