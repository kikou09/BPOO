public class Hearthstone {
	
	public static void main(String [] args)
	{
		
	}
	
	public ArrayList CreerCartesJaina(Heros h)
	{
		ArrayList<ICarte> CartesJaina = new ArrayList<ICarte> ();
		Sort flamme = new Sort ("Choc de Flamme", 7, h, new Capacite("Attaque massive", "inflige 4 pts de dégats a tous les serviteurs adverses", 4);
		CartesJaina.add(flamme);
		Sort givre = new Sort ("Eclair de givre", 2, h, new Capacite("Attaque de givre", "inflige 3 pts de dégats aux personnages cibles", 3);
		CartesJaina.add(givre);
		Sort arcanes = new Sort ("Intelignece des arcanes", 2, h, new Pioche(2));
		CartesJaina.add(arcanes);
		Sort mirroir = new Sort ("Image mirroir", 1, h, new ImageMirroir(); // a faire
		CartesJaina.add(flamme);
		Sort explosion = new Sort ("Explosion Pyrotechnique", 10, h, new Capacite("Explosion Pyrotechnique", "inflige 10 pts de dégats a tous les serviteurs adverses", 10);
		CartesJaina.add(flamme);
		
		
	}
	
	public ArrayList CreerCartesRexxar(Heros h)
	{
		ArrayList<ICarte> CartesRexxar = new ArrayList<ICarte> ();
		Sort chasseur = new Sort ("Marque du Chasseur", 1, h, new Chasseur();// a faire
		CartesRexxar.add(chasseur);
		Sort tirarcanes = new Sort ("Tir des arcanes", 1, h, new Capacite("Tir des arcanes", "inflige 2 pts de dégats au personnage cible", 2);
		CartesRexxar.add(tirarcanes);
		Sort chiens = new Sort ("Lachez les chiens", 3, h, new Lachezchiens()); // a faire
		CartesRexxar.add(chiens);
		Sort tuer = new Sort ("Ordre de tuer", 3, h, new Capacite("Ordre de tuer", "Inflige 3 pts de degats au personnage cible", 3); 
		CartesRexxar.add(tuer);
		Sort busard = new Serviteur ("Busard affamé", 5, h, 3, 2, new Pioche(1) );
		CartesRexxar.add(busard);
		
		
	}
	
	public ArrayList CreerCartesNeutres(IJoueur proprietaire)
	{
		ArrayList<ICarte> CartesNeutres = new ArrayList<ICarte> ();
		Serviteur chasse-marree=new Serviteur ("Chasse maréé murloc" , 2, proprietaire , 2 , 1 , new Invocation ("Cri de guerre" , "Invocation d'un serviteur 1/1" , new Serviteur ("Serviteur de Chasse-maree" , 0 , proprietaire , 1, 1,null)));
		CartesNeutres.add(chasse-marree);
		
		Serviteur Champion_hurlevent= new Serviteur ("Champion de Hurlevent" , 7 , proprietaire ,  6 ,6 , new Capacite ( " Bonus de hurlevent " , "Effet sur les serviteurs donnant un bonus +1/+1 " , 1); //????
		
		Serviteur Chef_raid = new Serviteur ("Chef de Raid" , 3 , proprietaire , 2 , 2 , new Capacite ( " Bonus du chef de raid " , " Effet sur les serviteurs alliés donnant un bonus +1/0" , 1  ) ; // ????? 
		
		Serviteur missiliere= new Serviteur ("La missilière témeraire " , 6 , proprietaire , 5 ,  2 , new Charge ());
		CartesNeutres.add(missiliere);
		
		Serviteur ogre_magi= new Serviteur ( "L'ogre-magi" , 4 , proprietaire , 4 , 4 , new Provocation ());
		CartesNeutres.add(ogre_magi);
		
		Serviteur archimage = new Serviteur ("Archimage" , 6 , proprietaire , 4 ,7 , new Provocation());
		CartesNeutres.add(archimage);
		
		Serviteur gnome = new Serviteur ("Gnôme lépreux " , 1 ,proprietaire , 1 , 1 , new Capacite ( " Attaque du lépreux " , "Inflige 2 points de dégats au héros " , 2 );
		CartesNeutres.add(gnome);
		
		Serviteur golem = new Serviteur ( " Golem des moissons" , 3 , proprietaire , 2 , 3 , new Invocation ( "Golemisation " , " Invoque un Golem endomage 2/1" , new Serviteur ( " Serviteur de Golem " , 0 , proprietaire , 2 , 1 ,null)));
		CartesNeutres.add(golem);
		
		Sort charge = new Charge();
		CartesNeutres.add(charge);
		
		Sort attaque_mentale= new Sort ( " Attaque mentale " , 2 ,  proprietaire , new Capacite ( "Attaque mentale " , "Inflige 5 points de dégats au héros " , 5);
		CartesNeutres.add(attaque_mentale);
		
		
	}
