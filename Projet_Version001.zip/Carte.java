public abstract class Carte implements ICarte{

	private String nom;
	private int cout_mana;
	private IJoueur proprietaire;
	
	public Carte(String n, int c , IJoueur j)
	{
		if(n==null)
			throw new ExceptionHearthsone("Le nom ne doit pas être null");
		if(n=="")
			throw new ExceptionHearthsone("Le nom ne doit pas être vide");
		this.nom=n;
		if(c<0)
			throw new ExceptionHearthsone("Le cout en mana doit être positif ");	
		this.cout_mana=c;
		this.proprietaire=j;
	}
	
	public final String getNom(){
		return this.nom;
	}
	
	public final int getMana(){
		return this.cout_mana;
	}
	
	public final IJoueur getProprietaire(){
		return this.proprietaire;
	}
	public final boolean disparait()
	{
		this.proprietaire=null;  ???? 
	}
	
	public void setProprietaire(IJoueur j){
		this.proprietaire=j;
	}
	
	public String toString(){
		return "Carte [ Nom = " + this.nom + " Cout = " + this.cout_mana + "]" ;
	}
	
	public boolean equals(Object o){
		if(o==null)
			return false ;
		if(this==o)	
			return true;
		if(! o instanceof Carte)
			return false;
		o=(Carte)o;
		if ((this.nom==null) && ( o.nom != null))
			return false;
		else if (!this.nom.equals(o.nom))
			return false;
		if(this.cout_mana != o.cout_mana)
			return false;
		return true;
	}
		
			
			
			
}		


