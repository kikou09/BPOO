public final class ExceptionHearthsone extends Exception {
	
	public ExceptionHearthsone ( String nom){
		super(nom);
	}
}