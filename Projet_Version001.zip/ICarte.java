public abstract interface ICarte extends Cloneable{

	public abstract boolean	disparait();
	public abstract void executerAction(java.lang.Object cible)throws jeu.ExceptionHearthstone;
	public abstract void executerEffetDebutMiseEnJeu(java.lang.Object cible) throws jeu.ExceptionHearthstone;
	public abstract void executerEffetDebutTour(java.lang.Object cible)throws jeu.ExceptionHearthstone;
	public abstract void executerEffetDisparition(java.lang.Object cible) throws jeu.ExceptionHearthstone;
	public abstract void executerEffetFinTour(java.lang.Object cible)throws jeu.ExceptionHearthstone;
	public abstract int	getCout() ;
	public abstract  String	getNom() ;
	public abstract IJoueur	getProprietaire() ;
}