public final class Joueur implements IJoueur {
	
	private String pseudo;
	private int mana;
	private int stockMana;
	private Heros heros;
	private Deck deck;
	private ArrayList<ICarte> main ; ??? 
	private ArrayList<ICarte> cartes_posés;
	private boolean joue;
	
	
	public Joueur ( String p , Heros h ){
		if (h==null)
			throw new ExceptionHearthsone("Le heros ne doit pas être null ");
		if (p==null)
			throw new ExceptionHearthsone("Le pseudo ne doit pas être null");
		if(p=="")
			throw new ExceptionHearthsone("Le pseudo ne doit pas être vide");
		this.pseudo=p;
		this.heros=h;
		this.mana=0;
	}
	
	public final String getPseudo() {
		return this.pseudo;
	}
	
	public final Heros getHeros(){
		return this.heros;
	}
	
	public final Deck getDeck () {
		return this.deck;
	}
	
	public final ArrayList<ICarte> getMain(){
		return this.main;
	}
	
	public final int getMana() {
		return this.mana;
	}
	
	public final int getStockMana () {
		return this.stockMana;
	}
	
	public ICarte getCarteEnJeu(String nom){
		
	}
	
	public ICarte getCarteEnMain (String nom ){
		
	}
	
	public final String toString()
	{
		return str = "Joueur [pseudo=" + this.pseudo + ", heros=" + this.heros + ", mana=" + this.mana + "]\n";
	}
	
	public final void prendreTour()throws jeu.ExceptionHearthstone {
		if(this.joue)
			throw new ExceptionHearthsone ("Tu as deja le tour ");
		this.joue=true;
		if (this.mana <10)
			mana++;
		this.stockMana=this.mana;
		if(this.heros.getPouvoir() != null)
			//il peut executer son pouvoir
		
	}
		
	public final void finirTour () throws jeu.ExceptionHearthstone{
		if(!this.joue)
			throw new ExceptionHearthsone("Ce n'est pas ton tour "); 
		this.joue=false;
		Plateau.finirTour(this);
	}
	
	public final void piocher() throws jeu.ExceptionHearthstone{
		if(this.deck.getCartes_Deck.size()!=0)
		{
			int i = (int)(Math.random() * i);
			ICarte carte_p = this.deck.getCartes_Deck().get(i);
			this.main.add(carte_p);
			this.deck.getCartes_Deck.remove(i);
		}
	}
	
	public final void jouerCarte(ICarte carte)throws jeu.ExceptionHearthstone{
		if (!this.main.contains(carte))
			throw new ExceptionHearthsone("Tu n'as pas cette carte dans ta main ! ");
		if(mana<carte.getMana())
			throw new ExceptionHearthsone("Tu n'as pas assez de mana");
		this.mana=this.mana - carte.getMana()
		this.main.remove(carte);
		this.cartes_posés.add(carte);
		//Test action sans cible
	}
	
	public final void jouerCarte(ICarte carte, java.lang.Object cible)throws jeu.ExceptionHearthstone{
		if (!this.main.contains(carte))
			throw new ExceptionHearthsone("Tu n'as pas cette carte dans ta main ! ");
		if(mana<carte.getMana())
			throw new ExceptionHearthsone("Tu n'as pas assez de mana");
		this.mana=this.mana - carte.getMana()
		this.main.remove(carte);
		this.cartes_posés.add(carte);
		//Test action avec cible
	}

	public final void perdreCarte(ICarte carte)throws jeu.ExceptionHearthstone{
		if (!this.cartes_posés.contains(carte))
			throw new ExceptionHearthsone("Carte non posés sur le plateau");
		this.cartes_posés.remove(carte);
	}
	
	public final void utiliserCarte(ICarte carte, java.lang.Object cible)throws jeu.ExceptionHearthstone{
		if (!this.cartes_posés.contains(carte))
			throw new ExceptionHearthsone("Carte non posés sur le plateau");
		carte.ExecuterAction();
		if (carte.disparait() && this.cartes_posés.contains(carte))
			this. cartes_posés.remove(carte);
	}
		
	public final void utiliserPouvoir(java.lang.Object cible)throws jeu.ExceptionHearthstone{
		if(this.heros.getPouvoir() ==null)
			throw new ExceptionHearthsone("Ton héros ne possède pas de pouvoir ");
		this.heros.utiliserPouvoir(cible);
	
	public abstract ICarte getCarteEnJeu();
	public abstract ICarte getCarteEnMain();
	public abstract ArrayList<ICarte> getJeu();
	
	
}