public final class Charge extends Capacite
{
	
	public Charge()
	{
		super("Charge" , "Cette capacite permet à un serviteur de ne pas attendre avant d'attaquer");
	}
	
	public final void executerAction(Object cible) throws jeu.ExceptionHearthstone
	{
		if(cible==null)
		{
			throw new ExceptionHearthstone("Il faut une cible");
		}
		if(cible.getClass() != Serviteur.getClass())
		{
			throw new ExceptionHearthstone ("Charge se fait sur un serviteur");
		}
		
		cible=(Serviteur)cible;
		cible.setAttente(0);
	}

	