public final class Heros implements cloneable{

	private String nom ;
	private int pt_vie;
	private int vie_max;
	private int jouer; ???
	private ArrayListe listeHeros ????
	private ArrayList<ICarte> cartes ;
	private Capacite pouvoir ; 
	
	public Heros(String n , Capacite p) {
		if (n==null)
			throw new ExceptionHearthsone("Le nom ne doit pas être null");
		if(p==null)
			throw new ExceptionHearthsone("La capacité de doit pas être null");
		if(n=="")
			throw new ExceptionHearthsone("Le nom ne doit pas être vide");
		this.nom=n;
		this.pt_vie=15;
		this.vie_max=15;
		this.pouvoir=p;
	}
	
	public Heros (String n )
	{
		if(n==nul)
			throw new ExceptionHearthsone("Le nom ne doit pas être null");
		if(n=="")
			throw new ExceptionHearthsone("Le nom ne doit pas être vide");
		this.nom=n;
		this.pt_vie=15;
		this.vie_max=15;
		this.pouvoir=null;
	}
	
	public Heros( Hero h){
		this.nom=h.nom;
		this.pt_vie=h.pt_vie;
		this.vie_max=h.vie_max;
		this.pouvoir=h.pouvoir;
	}
	
	public String getNom (){
		return this.nom;
	}
	
	public ICapacite getPouvoir () {
		return this.pouvoir;
	}
	
	public int GetPointDeVie{
		return this.pt_vie;
	}
	
	public void perteVie(int nb){
		this.pt_vie=this.pt_vie - nb;
	}
	
	public boolean estMort(){
		return this.pt_vie <= 0;
	}
	
	private object clone()
	{
		return new Heros (this);
	}
	
	public String toString(){
		return " Heros [ nom = " + this.nom + " point de vie = " + this.pt_vie + " ]" ;
	}
	
	public boolean equals(Object o){
	
	
	
	}
	

}