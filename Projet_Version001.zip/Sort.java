public final class Sort extends Carte {
	private Capacite capacite;
	
	public Sort ( String n , int cout , IJoueur joueur , Capacite c )
	{
		super(n,cout,joueur);
		this.capacite=c;
	}
	
	
	public Capacite getCapacite(){
		return this.capacite;
	}
	
	public String toString(){
		return "Sort [ " + super.toString() + " capacite = " + this.capacite + "]" ;
	}

}